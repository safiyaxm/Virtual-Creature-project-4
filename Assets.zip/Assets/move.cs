using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public GameObject donut;
    public GameObject Riggedhorse;
    public float speed;

    // Update is called once per frame
    void Update()
    {
        donut.transform.position = Vector3.MoveTowards(donut.transform.position, Riggedhorse.transform.position, speed);
        
    }
}
